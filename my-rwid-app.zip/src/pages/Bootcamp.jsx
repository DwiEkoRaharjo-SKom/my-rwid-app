import React from "react";
export default function Bootcamp() {
  return (
    <div className="dummy-page" style={{minHeight:'60vh',display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column'}}>
      <h2>Halaman Bootcamp</h2>
      <p>Ini adalah halaman Bootcamp (dummy page).</p>
    </div>
  );
}
