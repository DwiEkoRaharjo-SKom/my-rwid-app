import React from "react";
export default function 100millionprojects() {
  return (
    <div className="container" style={{marginTop:'2em',textAlign:'center'}}>
      <div className="card">
        <h2 style={{fontWeight:800,color:"var(--color-primary)",fontSize:'1.38em',marginBottom:'1em'}}>RWID100MillionRupiahProjects</h2>
        <p style={{color:"#444",fontSize:'1.07em'}}>Konten <b>RWID100MillionRupiahProjects</b> akan segera tersedia.</p>
      </div>
    </div>
  );
}
