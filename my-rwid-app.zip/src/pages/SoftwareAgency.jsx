import React from "react";
export default function SoftwareAgency() {
  return (
    <div className="dummy-page" style={{minHeight:'60vh',display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column'}}>
      <h2>Halaman SoftwareAgency</h2>
      <p>Ini adalah halaman SoftwareAgency (dummy page).</p>
    </div>
  );
}
