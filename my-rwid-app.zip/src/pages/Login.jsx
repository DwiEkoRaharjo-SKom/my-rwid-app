import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      navigate("/dashboard");
    }
  }, [user, navigate]);

  const handleChange = (e) => {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
    setError("");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      const ok = login(form);
      if (ok) {
        navigate("/dashboard");
      } else {
        setLoading(false);
        setError("Email atau password salah.");
      }
    }, 600);
  };

  return (
    <div className="container">
      <div className="card" style={{ marginTop: "2.8em", maxWidth: 390 }}>
        <h2 className="text-center mb-6">Masuk ke RWID App</h2>
        <form onSubmit={handleSubmit}>
          <label htmlFor="email">Email</label>
          <input
            id="email"
            name="email"
            type="email"
            autoComplete="username"
            value={form.email}
            onChange={handleChange}
            required
          />
          <label htmlFor="password">Password</label>
          <input
            id="password"
            name="password"
            type="password"
            autoComplete="current-password"
            value={form.password}
            onChange={handleChange}
            required
          />
          {error && (
            <div style={{ color: "#b91c1c", marginBottom: "1em" }}>{error}</div>
          )}
          <button className="w-full mt-8 transition" type="submit" disabled={loading}>
            {loading ? "Memeriksa..." : "Masuk"}
          </button>
        </form>
        <div className="text-center mt-8" style={{ fontSize: "0.97em", color: "#616161" }}>
          <span>
            Email: <b>user@rwid.com</b>
            <br />
            Password: <b>rwid123</b>
          </span>
        </div>
      </div>
    </div>
  );
}
