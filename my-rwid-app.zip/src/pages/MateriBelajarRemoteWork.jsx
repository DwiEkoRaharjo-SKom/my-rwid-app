import React from "react";
export default function MateriBelajarRemoteWork() {
  return (
    <div className="dummy-page" style={{minHeight:'60vh',display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column'}}>
      <h2>Halaman MateriBelajarRemoteWork</h2>
      <p>Ini adalah halaman MateriBelajarRemoteWork (dummy page).</p>
    </div>
  );
}
