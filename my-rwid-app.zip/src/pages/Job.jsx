import React from "react";
export default function Job() {
  return (
    <div className="dummy-page" style={{minHeight:'60vh',display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column'}}>
      <h2>Halaman Job</h2>
      <p>Ini adalah halaman Job (dummy page).</p>
    </div>
  );
}
