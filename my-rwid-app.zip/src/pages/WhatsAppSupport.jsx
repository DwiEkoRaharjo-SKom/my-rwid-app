import React from "react";
export default function WhatsAppSupport() {
  return (
    <div className="dummy-page" style={{minHeight:'60vh',display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column'}}>
      <h2>Halaman WhatsAppSupport</h2>
      <p>Ini adalah halaman WhatsAppSupport (dummy page).</p>
    </div>
  );
}
