import React from "react";
import { Routes, Route } from "react-router-dom";
import Homepage from "./pages/Homepage";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import AksesMateri from "./pages/AksesMateri";
import ProtectedRoute from "./components/ProtectedRoute";

export default function Router() {
  return (
    <Routes>
      <Route path="/" element={<Homepage />} />
      <Route path="/login" element={<Login />} />
      <Route path="/dashboard" element={
        <ProtectedRoute>
          <Dashboard />
        </ProtectedRoute>
      } />
      <Route path="/akses-materi" element={<AksesMateri />} />
      <Route path="*" element={<div style={{ padding: '2rem' }}><h2>404 - Halaman tidak ditemukan</h2><a href="/">Kembali ke Beranda</a></div>} />
    </Routes>
  );
}
